
window.onload=function (){
	
//	联系我们
$(function(){
    H_qqServer={};
    H_qqServer.clickOpenServer = function () {
        $('.tel_client_open').click(function(){
            $('.tel_client').animate({
                right: '-80'
            },400);
            $('.tel_client_content').animate({
                right: '0',
                opacity: 'show'
            }, 800 );
        });
        $('.tel_client_close').click(function(){
            $('.tel_client').animate({
                right: '30',
                opacity: 'show'
            },400);
            $('.tel_client_content').animate({
                right: '-400',
                opacity: 'show'
            }, 800 );
        });
    };
    H_qqServer.run= function () {
        this.clickOpenServer();
    };
    H_qqServer.run();
}); 

//	//		导航栏的滑动
//	     var mySwiper1 = new Swiper('#nav',{
//	      freeMode : true,
//	      freeModeSticky : true,
//	      slidesPerView : 'auto',
//	      onClick: function(swiper){
//	         mySwiper1.slideTo( mySwiper1.clickedIndex);
//	         mySwiper2.slideTo( mySwiper1.clickedIndex);
//	      	}	
//		});
//		
//		var mySwiper1 = new Swiper('.swiper2',{
//	      freeMode : true,
//	      freeModeSticky : true,
//	      slidesPerView : 'auto',
//	      onClick: function(swiper){
//	         mySwiper1.slideTo( mySwiper1.clickedIndex);
//	         mySwiper2.slideTo( mySwiper1.clickedIndex);
//	      	}	
//		});
}